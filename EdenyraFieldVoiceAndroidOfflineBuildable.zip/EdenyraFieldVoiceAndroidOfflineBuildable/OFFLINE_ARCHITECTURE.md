# Offline architecture

The FastAPI server is no longer part of the runtime architecture.

| Previous component | Offline Android replacement |
|---|---|
| FastAPI | Direct Kotlin function calls |
| faster-whisper | whisper.cpp Android AAR |
| agricultural_parser.py | AgriculturalParser.kt |
| SQLAlchemy + SQLite | SQLiteOpenHelper |
| /confirm-action | DatabaseHelper.insertAction() |
| /parse-text | AgriculturalParser.parse() |
| /export/json | ExportUtils.toJson() |
| /export/csv | ExportUtils.toCsv() |

The only runtime permission is RECORD_AUDIO.
