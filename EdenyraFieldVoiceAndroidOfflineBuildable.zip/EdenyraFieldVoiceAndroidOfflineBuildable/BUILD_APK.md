# Generar el APK instalable

El proyecto incluye `.github/workflows/build-apk.yml`.

Al subir esta carpeta a un repositorio GitHub, abre **Actions → Build Android APK → Run workflow**.
El workflow instala el SDK Android, descarga el modelo Whisper base, compila la app y publica el artefacto:

`Edenyra-Field-Voice-offline.apk`

Es un APK **debug firmado**, instalable directamente en un teléfono Android ARM64. Android puede pedir permiso para instalar aplicaciones desconocidas desde el navegador/gestor de archivos.

La app no necesita Internet en ejecución: audio, Whisper, parser agrícola, SQLite e histórico funcionan localmente.
