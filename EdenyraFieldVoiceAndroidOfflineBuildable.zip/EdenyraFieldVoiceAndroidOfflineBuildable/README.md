# Edenyra Field Voice Android — OFFLINE

Esta versión elimina por completo la dependencia del backend FastAPI en ejecución.

## Arquitectura

Todo se ejecuta dentro del teléfono:

```text
Micrófono Android
      ↓
WAV PCM 16 kHz
      ↓
Whisper.cpp (modelo multilingual base)
      ↓
Transcripción en español
      ↓
Parser agrícola Kotlin
      ↓
Formulario editable / validación
      ↓
SQLite local
      ↓
Historial + exportación CSV/JSON
```

No hay HTTP, no hay servidor y el Manifest no solicita permiso de Internet.

## Qué se ha movido del backend a Android

- `faster-whisper` → `whisper.cpp` on-device mediante `whisper-android`.
- `agricultural_parser.py` → `AgriculturalParser.kt`.
- SQLite de FastAPI → `SQLiteOpenHelper` local (`edenyra_offline.db`).
- `/confirm-action` → inserción directa en SQLite.
- `/export/json` y `/export/csv` → exportación local mediante el selector de archivos Android.
- `/parse-text` → reinterpretación inmediata dentro de la app.

## Primer build

La aplicación funciona offline **después de instalarla**, pero el primer build necesita Internet para:

1. descargar las dependencias Gradle;
2. descargar `ggml-base.bin` (~142 MB) desde el repositorio oficial de whisper.cpp.

El `app/build.gradle.kts` ejecuta automáticamente `downloadWhisperModel` y coloca el modelo en:

```text
app/src/main/assets/models/ggml-base.bin
```

Después el modelo queda empaquetado dentro del APK y no vuelve a necesitar red.

## Abrir

1. Abre la carpeta del proyecto en Android Studio.
2. Espera a que Gradle sincronice y descargue el modelo.
3. Conecta un teléfono Android físico ARM64.
4. Pulsa Run.
5. Acepta permiso de micrófono.
6. Activa modo avión y prueba la app: debe seguir transcribiendo, interpretando, guardando y exportando.

## Importante: dispositivo

La dependencia gratuita usada para Whisper on-device incluye `arm64-v8a`. Es la arquitectura de la gran mayoría de teléfonos Android actuales, pero un emulador x86_64 normal no servirá. Para la demo usa un teléfono Android físico ARM64.

## Modelo de voz

Se usa `ggml-base.bin`, multilingüe (~142 MB), porque ofrece mejor equilibrio entre precisión en español, tamaño y velocidad que `tiny`. Si más adelante quieres priorizar precisión y el teléfono tiene potencia y almacenamiento suficientes, se puede pasar a `small` (~466 MB).

## Prueba recomendada

Di:

> Hoy he abonado la parcela 24 con 30 kilos de nitrato cálcico.

La aplicación debería producir aproximadamente:

```text
Parcela: 24
Actuación: fertilizacion
Producto: nitrato cálcico
Cantidad: 30
Unidad: kg
```

Corrige cualquier campo si es necesario y pulsa **Confirmar registro**. El dato se guarda únicamente en el teléfono.
