plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.edenyra.fieldvoice"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.edenyra.fieldvoice"
        minSdk = 26
        targetSdk = 35
        versionCode = 2
        versionName = "0.2-offline"

        ndk {
            abiFilters += listOf("arm64-v8a")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    androidResources {
        // The Whisper model is already a compressed binary. Keep it uncompressed
        // so whisper.cpp can load it efficiently from the APK assets.
        noCompress += "bin"
    }
}

dependencies {
    implementation("dev.ffmpegkit-maintained:whisper-android:1.0.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")
}

// The model is intentionally not stored in this ZIP because it is ~142 MB.
// The first Android build downloads it and packages it into the APK. Once the
// APK is installed, Edenyra Field Voice needs no network connection at runtime.
val whisperModelUrl = "https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-base.bin"
val whisperModelFile = layout.projectDirectory.file("src/main/assets/models/ggml-base.bin").asFile

tasks.register("downloadWhisperModel") {
    outputs.file(whisperModelFile)

    doLast {
        if (whisperModelFile.exists() && whisperModelFile.length() > 100_000_000L) {
            println("Whisper model already present: ${whisperModelFile.absolutePath}")
            return@doLast
        }

        whisperModelFile.parentFile.mkdirs()
        println("Downloading multilingual Whisper base model (~142 MB)...")

        val connection = java.net.URI(whisperModelUrl).toURL().openConnection() as java.net.HttpURLConnection
        connection.instanceFollowRedirects = true
        connection.connectTimeout = 30_000
        connection.readTimeout = 120_000
        connection.setRequestProperty("User-Agent", "EdenyraFieldVoiceAndroid/0.2")

        connection.inputStream.use { input ->
            whisperModelFile.outputStream().buffered().use { output ->
                input.copyTo(output)
            }
        }
        connection.disconnect()

        check(whisperModelFile.length() > 100_000_000L) {
            "Whisper model download looks incomplete (${whisperModelFile.length()} bytes). Delete it and rebuild."
        }
        println("Whisper model ready: ${whisperModelFile.length() / 1024 / 1024} MB")
    }
}

tasks.named("preBuild").configure {
    dependsOn("downloadWhisperModel")
}
