The first Gradle build automatically downloads ggml-base.bin (~142 MB) here.
The resulting APK packages the model, so the installed app works fully offline.
