package com.edenyra.fieldvoice

data class AgriculturalData(
    val fecha: String,
    val parcela: String?,
    val tipoActuacion: String,
    val producto: String?,
    val cantidad: Double?,
    val unidad: String?,
    val textoOriginal: String,
    val estado: String = "pendiente_confirmacion",
    val camposFaltantes: List<String> = emptyList()
)

data class FieldAction(
    val id: Long,
    val fecha: String,
    val parcela: String,
    val tipoActuacion: String,
    val producto: String?,
    val cantidad: Double?,
    val unidad: String?,
    val textoOriginal: String,
    val estado: String,
    val createdAt: String
)
