package com.edenyra.fieldvoice

import java.time.LocalDate
import java.util.Locale

object AgriculturalParser {

    private val fertilizerKeywords = listOf(
        "nitrato cálcico", "nitrato calcico", "urea", "fertilizante", "abono",
        "nitrato", "fosfato", "potasio", "sulfato amónico", "sulfato amonico"
    )

    private val phytosanitaryKeywords = listOf(
        "azufre", "cobre", "fungicida", "herbicida", "insecticida", "acaricida",
        "fitosanitario", "sulfato cúprico", "sulfato cuprico"
    )

    private val corrections = linkedMapOf(
        "azufes" to "azufre",
        "azufes." to "azufre.",
        "nitrato calcico" to "nitrato cálcico",
        "fitos sanitario" to "fitosanitario",
        "sulfato cupico" to "sulfato cúprico",
        "sulfato cúprico" to "sulfato cúprico"
    )

    private val numberWords = linkedMapOf(
        "un" to 1.0, "una" to 1.0, "uno" to 1.0,
        "dos" to 2.0, "tres" to 3.0, "cuatro" to 4.0, "cinco" to 5.0,
        "seis" to 6.0, "siete" to 7.0, "ocho" to 8.0, "nueve" to 9.0,
        "diez" to 10.0, "once" to 11.0, "doce" to 12.0, "trece" to 13.0,
        "catorce" to 14.0, "quince" to 15.0, "veinte" to 20.0,
        "treinta" to 30.0, "cuarenta" to 40.0, "cincuenta" to 50.0,
        "sesenta" to 60.0, "setenta" to 70.0, "ochenta" to 80.0,
        "noventa" to 90.0, "cien" to 100.0
    )

    fun parse(text: String): AgriculturalData {
        val original = text.trim()
        var normalized = original.lowercase(Locale("es", "ES"))

        corrections.forEach { (wrong, correct) ->
            normalized = normalized.replace(wrong, correct)
        }

        normalized = normalizeNumberWords(normalized)

        val parcela = Regex("parcela\\s+(?:p[-\\s]?)?(\\d+)", RegexOption.IGNORE_CASE)
            .find(normalized)?.groupValues?.getOrNull(1)

        var type = when {
            listOf("abonado", "aboné", "abone", "fertiliz", "abono", "fertilizado")
                .any { normalized.contains(it) } -> "fertilizacion"

            listOf("tratado", "tratamiento", "aplicado", "fumigado", "fitosanitario", "sulfatado")
                .any { normalized.contains(it) } -> "tratamiento_fitosanitario"

            listOf("regado", "riego", "regando", "he regado")
                .any { normalized.contains(it) } -> "riego"

            listOf("tractor", "laboreo", "arado", "desbrozado", "desbroce")
                .any { normalized.contains(it) } -> "trabajo_campo"

            else -> "otro"
        }

        var cantidad: Double? = null
        var unidad: String? = null

        val quantityMatch = Regex(
            "(\\d+(?:[.,]\\d+)?)\\s*(kilos?|kg|litros?|l|gramos?|g|horas?|h|minutos?|min)\\b",
            RegexOption.IGNORE_CASE
        ).find(normalized)

        if (quantityMatch != null) {
            cantidad = quantityMatch.groupValues[1].replace(',', '.').toDoubleOrNull()
            unidad = normalizeUnit(quantityMatch.groupValues[2])
        }

        var producto: String? = null

        val productAfterQuantity = Regex(
            "\\d+(?:[.,]\\d+)?\\s*(?:kilos?|kg|litros?|l|gramos?|g)\\s+de\\s+(.+?)(?:[.,;]|$)",
            setOf(RegexOption.IGNORE_CASE)
        ).find(normalized)

        if (productAfterQuantity != null) {
            producto = productAfterQuantity.groupValues[1].trim()
        }

        if (producto.isNullOrBlank()) {
            val productAfterCon = Regex("\\bcon\\s+(.+?)(?:[.,;]|$)", RegexOption.IGNORE_CASE)
                .find(normalized)
                ?.groupValues
                ?.getOrNull(1)
                ?.trim()

            if (!productAfterCon.isNullOrBlank()) {
                producto = productAfterCon
                    .replace(
                        Regex("^\\d+(?:[.,]\\d+)?\\s*(?:kilos?|kg|litros?|l|gramos?|g)\\s+de\\s+", RegexOption.IGNORE_CASE),
                        ""
                    )
                    .trim()
            }
        }

        // If Whisper omitted the verb, infer the operation from agricultural vocabulary.
        val productLower = producto?.lowercase(Locale("es", "ES")) ?: normalized
        if (type == "otro") {
            type = when {
                fertilizerKeywords.any { productLower.contains(it) } -> "fertilizacion"
                phytosanitaryKeywords.any { productLower.contains(it) } -> "tratamiento_fitosanitario"
                else -> type
            }
        }

        // Riego and field work often use duration as the useful quantity.
        if (type == "riego" && cantidad == null) {
            val duration = Regex("(\\d+(?:[.,]\\d+)?)\\s*(horas?|h|minutos?|min)\\b", RegexOption.IGNORE_CASE)
                .find(normalized)
            if (duration != null) {
                cantidad = duration.groupValues[1].replace(',', '.').toDoubleOrNull()
                unidad = normalizeUnit(duration.groupValues[2])
            }
        }

        val missing = mutableListOf<String>()
        if (parcela.isNullOrBlank()) missing += "parcela"

        if (type == "fertilizacion" || type == "tratamiento_fitosanitario") {
            if (producto.isNullOrBlank()) missing += "producto"
            if (cantidad == null) missing += "cantidad"
        }

        return AgriculturalData(
            fecha = LocalDate.now().toString(),
            parcela = parcela,
            tipoActuacion = type,
            producto = producto,
            cantidad = cantidad,
            unidad = unidad,
            textoOriginal = original,
            camposFaltantes = missing
        )
    }

    private fun normalizeUnit(raw: String): String = when (raw.lowercase(Locale.ROOT)) {
        "kilo", "kilos", "kg" -> "kg"
        "litro", "litros", "l" -> "L"
        "gramo", "gramos", "g" -> "g"
        "hora", "horas", "h" -> "h"
        "minuto", "minutos", "min" -> "min"
        else -> raw
    }

    private fun normalizeNumberWords(text: String): String {
        var value = text
        numberWords.forEach { (word, number) ->
            val replacement = if (number % 1.0 == 0.0) number.toInt().toString() else number.toString()
            value = value.replace(Regex("\\b${Regex.escape(word)}\\b", RegexOption.IGNORE_CASE), replacement)
        }
        return value
    }
}
