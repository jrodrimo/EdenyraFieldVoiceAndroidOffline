package com.edenyra.fieldvoice

import android.content.Context
import dev.ffmpegkit.whisper.Whisper
import dev.ffmpegkit.whisper.WhisperConfig

class OfflineTranscriber(private val context: Context) {

    suspend fun transcribe(audioPath: String): String {
        val model = Whisper.loadModelFromAsset(
            context,
            "models/ggml-base.bin"
        )

        return try {
            Whisper.transcribe(
                model,
                audioPath,
                WhisperConfig(language = "es")
            ).text.trim()
        } finally {
            Whisper.releaseModel(model)
        }
    }
}
