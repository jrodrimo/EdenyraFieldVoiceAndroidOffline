package com.edenyra.fieldvoice

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import kotlinx.coroutines.runBlocking
import java.io.File
import java.util.concurrent.Executors

class MainActivity : Activity() {

    companion object {
        private const val AUDIO_PERMISSION_REQUEST = 1001
        private const val EXPORT_CSV_REQUEST = 2001
        private const val EXPORT_JSON_REQUEST = 2002
    }

    private val executor = Executors.newSingleThreadExecutor()
    private val wavRecorder = WavRecorder()

    private lateinit var db: DatabaseHelper
    private lateinit var transcriber: OfflineTranscriber

    private lateinit var recordButton: Button
    private lateinit var statusText: TextView
    private lateinit var transcriptionEdit: EditText
    private lateinit var reinterpretButton: Button
    private lateinit var formContainer: LinearLayout
    private lateinit var fechaEdit: EditText
    private lateinit var parcelaEdit: EditText
    private lateinit var tipoEdit: EditText
    private lateinit var productoEdit: EditText
    private lateinit var cantidadEdit: EditText
    private lateinit var unidadEdit: EditText
    private lateinit var warningText: TextView
    private lateinit var saveStatus: TextView
    private lateinit var historyContainer: LinearLayout

    private var audioFile: File? = null
    private var recording = false
    private var pendingExport: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = DatabaseHelper(this)
        transcriber = OfflineTranscriber(this)
        buildUi()
    }

    private fun buildUi() {
        val scroll = ScrollView(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(30))
        }
        scroll.addView(root)

        root.addView(TextView(this).apply {
            text = "🌱 Edenyra Field Voice"
            textSize = 28f
            setTypeface(null, Typeface.BOLD)
            gravity = Gravity.CENTER_HORIZONTAL
        })

        root.addView(TextView(this).apply {
            text = "Cuaderno de campo por voz · 100% offline"
            textSize = 16f
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(0, dp(4), 0, dp(6))
        })

        root.addView(TextView(this).apply {
            text = "Whisper, parser agrícola y SQLite se ejecutan en este dispositivo."
            textSize = 13f
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(0, 0, 0, dp(18))
        })

        recordButton = Button(this).apply {
            text = "🎤 Registrar actuación"
            textSize = 18f
            setPadding(dp(12), dp(14), dp(12), dp(14))
            setOnClickListener { toggleRecording() }
        }
        root.addView(recordButton, fullWidth())

        statusText = TextView(this).apply {
            text = "Pulsa el botón y describe lo que has hecho."
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(0, dp(12), 0, dp(18))
        }
        root.addView(statusText)

        root.addView(TextView(this).apply {
            text = "🎙️ Transcripción"
            setTypeface(null, Typeface.BOLD)
            textSize = 18f
        })

        transcriptionEdit = EditText(this).apply {
            minLines = 3
            gravity = Gravity.TOP
            hint = "Aquí aparecerá la transcripción local..."
        }
        root.addView(transcriptionEdit, fullWidth())

        reinterpretButton = Button(this).apply {
            text = "🔄 Reinterpretar texto"
            isEnabled = false
            setOnClickListener { reinterpretText() }
        }
        root.addView(reinterpretButton)

        formContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
            setPadding(0, dp(18), 0, 0)
        }
        root.addView(formContainer)

        formContainer.addView(TextView(this).apply {
            text = "🌾 Registro interpretado"
            setTypeface(null, Typeface.BOLD)
            textSize = 18f
        })

        fechaEdit = addField(formContainer, "Fecha")
        parcelaEdit = addField(formContainer, "Parcela")
        tipoEdit = addField(formContainer, "Actuación")
        productoEdit = addField(formContainer, "Producto")
        cantidadEdit = addField(
            formContainer,
            "Cantidad",
            InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL or InputType.TYPE_NUMBER_FLAG_SIGNED
        )
        unidadEdit = addField(formContainer, "Unidad")

        warningText = TextView(this).apply {
            setPadding(0, dp(8), 0, dp(8))
        }
        formContainer.addView(warningText)

        formContainer.addView(Button(this).apply {
            text = "✅ Confirmar registro"
            setOnClickListener { confirmAction() }
        })

        saveStatus = TextView(this).apply {
            setPadding(0, dp(10), 0, dp(16))
        }
        formContainer.addView(saveStatus)

        root.addView(Button(this).apply {
            text = "📋 Cargar historial local"
            setOnClickListener { loadHistory() }
        }, fullWidth())

        val exportRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        exportRow.addView(Button(this).apply {
            text = "⬇ CSV"
            setOnClickListener { exportCsv() }
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        exportRow.addView(Button(this).apply {
            text = "⬇ JSON"
            setOnClickListener { exportJson() }
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(exportRow, fullWidth())

        historyContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(12), 0, 0)
        }
        root.addView(historyContainer)

        setContentView(scroll)
    }

    private fun addField(
        parent: LinearLayout,
        label: String,
        inputType: Int = InputType.TYPE_CLASS_TEXT
    ): EditText {
        parent.addView(TextView(this).apply {
            text = label
            setTypeface(null, Typeface.BOLD)
            setPadding(0, dp(10), 0, dp(2))
        })
        return EditText(this).apply {
            this.inputType = inputType
            parent.addView(this, fullWidth())
        }
    }

    private fun toggleRecording() {
        if (recording) {
            stopRecording()
            return
        }

        if (
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.M &&
            checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), AUDIO_PERMISSION_REQUEST)
            return
        }

        startRecording()
    }

    private fun startRecording() {
        try {
            audioFile = File(cacheDir, "edenyra_${System.currentTimeMillis()}.wav")
            wavRecorder.start(audioFile!!)
            recording = true
            recordButton.text = "⏹ Terminar grabación"
            statusText.text = "🔴 Grabando localmente... habla de forma natural"
        } catch (e: Exception) {
            statusText.text = "❌ No se pudo iniciar la grabación: ${e.message}"
        }
    }

    private fun stopRecording() {
        wavRecorder.stop()
        recording = false
        recordButton.text = "🎤 Registrar actuación"

        val file = audioFile
        if (file == null || !file.exists() || file.length() <= 44L) {
            statusText.text = "❌ La grabación está vacía"
            return
        }

        statusText.text = "⏳ Transcribiendo en el teléfono..."

        executor.execute {
            try {
                val text = runBlocking {
                    transcriber.transcribe(file.absolutePath)
                }
                val agricultural = AgriculturalParser.parse(text)

                runOnUiThread {
                    transcriptionEdit.setText(text)
                    applyAgriculturalData(agricultural)
                    reinterpretButton.isEnabled = true
                    statusText.text = "✅ Audio transcrito e interpretado offline"
                }
            } catch (e: Exception) {
                runOnUiThread {
                    statusText.text = "❌ Error en transcripción local: ${e.message}"
                }
            }
        }
    }

    private fun reinterpretText() {
        val text = transcriptionEdit.text.toString().trim()
        if (text.isEmpty()) return
        val agricultural = AgriculturalParser.parse(text)
        applyAgriculturalData(agricultural)
        statusText.text = "✅ Texto reinterpretado localmente"
    }

    private fun applyAgriculturalData(a: AgriculturalData) {
        formContainer.visibility = View.VISIBLE
        fechaEdit.setText(a.fecha)
        parcelaEdit.setText(a.parcela.orEmpty())
        tipoEdit.setText(a.tipoActuacion)
        productoEdit.setText(a.producto.orEmpty())
        cantidadEdit.setText(a.cantidad?.let { formatNumber(it) }.orEmpty())
        unidadEdit.setText(a.unidad.orEmpty())

        warningText.text = if (a.camposFaltantes.isNotEmpty()) {
            "⚠️ Faltan datos: ${a.camposFaltantes.joinToString(", ")}"
        } else {
            "✅ Registro completo para revisión"
        }
    }

    private fun confirmAction() {
        val fecha = fechaEdit.text.toString().trim()
        val parcela = parcelaEdit.text.toString().trim()
        val tipo = tipoEdit.text.toString().trim()
        val product = productoEdit.text.toString().trim().ifEmpty { null }
        val quantity = cantidadEdit.text.toString().trim().replace(',', '.').toDoubleOrNull()
        val unit = unidadEdit.text.toString().trim().ifEmpty { null }
        val original = transcriptionEdit.text.toString().trim()

        if (fecha.isBlank() || parcela.isBlank() || tipo.isBlank() || original.isBlank()) {
            saveStatus.text = "⚠️ Fecha, parcela, actuación y transcripción son obligatorios."
            return
        }

        try {
            val id = db.insertAction(
                fecha = fecha,
                parcela = parcela,
                tipoActuacion = tipo,
                producto = product,
                cantidad = quantity,
                unidad = unit,
                textoOriginal = original
            )
            saveStatus.text = "✅ Registro guardado localmente con ID $id"
        } catch (e: Exception) {
            saveStatus.text = "❌ No se pudo guardar: ${e.message}"
        }
    }

    private fun loadHistory() {
        val actions = db.listActions()
        historyContainer.removeAllViews()
        historyContainer.addView(TextView(this).apply {
            text = "📋 Últimas actuaciones (SQLite local)"
            setTypeface(null, Typeface.BOLD)
            textSize = 18f
        })

        if (actions.isEmpty()) {
            historyContainer.addView(TextView(this).apply { text = "No hay registros." })
            return
        }

        actions.takeLast(20).reversed().forEach { item ->
            val quantity = buildString {
                item.cantidad?.let { append(formatNumber(it)) }
                item.unidad?.takeIf { it.isNotBlank() }?.let {
                    if (isNotEmpty()) append(" ")
                    append(it)
                }
            }

            historyContainer.addView(TextView(this).apply {
                text = buildString {
                    append("#${item.id} · ${item.fecha} · Parcela ${item.parcela}\n")
                    append(item.tipoActuacion)
                    item.producto?.takeIf { it.isNotBlank() }?.let { append(" · $it") }
                    if (quantity.isNotBlank()) append(" · $quantity")
                }
                setPadding(dp(10), dp(10), dp(10), dp(10))
            }, fullWidth())
        }
    }

    private fun exportCsv() {
        pendingExport = ExportUtils.toCsv(db.listActions())
        createDocument("text/csv", "edenyra_actuaciones.csv", EXPORT_CSV_REQUEST)
    }

    private fun exportJson() {
        pendingExport = ExportUtils.toJson(db.listActions())
        createDocument("application/json", "edenyra_actuaciones.json", EXPORT_JSON_REQUEST)
    }

    private fun createDocument(type: String, filename: String, requestCode: Int) {
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            this.type = type
            putExtra(Intent.EXTRA_TITLE, filename)
        }
        startActivityForResult(intent, requestCode)
    }

    @Deprecated("Deprecated in Android API; retained for minSdk-compatible MVP export flow")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        if (requestCode != EXPORT_CSV_REQUEST && requestCode != EXPORT_JSON_REQUEST) return

        val uri = data?.data ?: return
        val content = pendingExport ?: return
        try {
            contentResolver.openOutputStream(uri)?.bufferedWriter(Charsets.UTF_8)?.use {
                it.write(content)
            }
            statusText.text = "✅ Exportación guardada en el dispositivo"
        } catch (e: Exception) {
            statusText.text = "❌ Error exportando: ${e.message}"
        } finally {
            pendingExport = null
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == AUDIO_PERMISSION_REQUEST) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                startRecording()
            } else {
                statusText.text = "❌ Se necesita permiso de micrófono"
            }
        }
    }

    override fun onDestroy() {
        wavRecorder.release()
        executor.shutdownNow()
        db.close()
        super.onDestroy()
    }

    private fun formatNumber(value: Double): String =
        if (value % 1.0 == 0.0) value.toLong().toString() else value.toString()

    private fun fullWidth() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.WRAP_CONTENT
    )

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
