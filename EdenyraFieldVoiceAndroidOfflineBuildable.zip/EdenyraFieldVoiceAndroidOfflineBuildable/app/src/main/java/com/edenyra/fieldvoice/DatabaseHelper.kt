package com.edenyra.fieldvoice

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.time.Instant

class DatabaseHelper(context: Context) : SQLiteOpenHelper(
    context,
    "edenyra_offline.db",
    null,
    1
) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """
            CREATE TABLE field_actions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                fecha TEXT NOT NULL,
                parcela TEXT NOT NULL,
                tipo_actuacion TEXT NOT NULL,
                producto TEXT,
                cantidad REAL,
                unidad TEXT,
                texto_original TEXT NOT NULL,
                estado TEXT NOT NULL,
                created_at TEXT NOT NULL
            )
            """.trimIndent()
        )
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        // MVP v1: no migration required yet.
    }

    fun insertAction(
        fecha: String,
        parcela: String,
        tipoActuacion: String,
        producto: String?,
        cantidad: Double?,
        unidad: String?,
        textoOriginal: String
    ): Long {
        val values = ContentValues().apply {
            put("fecha", fecha)
            put("parcela", parcela)
            put("tipo_actuacion", tipoActuacion)
            if (producto == null) putNull("producto") else put("producto", producto)
            if (cantidad == null) putNull("cantidad") else put("cantidad", cantidad)
            if (unidad == null) putNull("unidad") else put("unidad", unidad)
            put("texto_original", textoOriginal)
            put("estado", "confirmado")
            put("created_at", Instant.now().toString())
        }
        return writableDatabase.insertOrThrow("field_actions", null, values)
    }

    fun listActions(): List<FieldAction> {
        val result = mutableListOf<FieldAction>()
        readableDatabase.query(
            "field_actions",
            null,
            null,
            null,
            null,
            null,
            "id ASC"
        ).use { cursor ->
            val idIndex = cursor.getColumnIndexOrThrow("id")
            val fechaIndex = cursor.getColumnIndexOrThrow("fecha")
            val parcelaIndex = cursor.getColumnIndexOrThrow("parcela")
            val typeIndex = cursor.getColumnIndexOrThrow("tipo_actuacion")
            val productIndex = cursor.getColumnIndexOrThrow("producto")
            val quantityIndex = cursor.getColumnIndexOrThrow("cantidad")
            val unitIndex = cursor.getColumnIndexOrThrow("unidad")
            val originalIndex = cursor.getColumnIndexOrThrow("texto_original")
            val statusIndex = cursor.getColumnIndexOrThrow("estado")
            val createdIndex = cursor.getColumnIndexOrThrow("created_at")

            while (cursor.moveToNext()) {
                result += FieldAction(
                    id = cursor.getLong(idIndex),
                    fecha = cursor.getString(fechaIndex),
                    parcela = cursor.getString(parcelaIndex),
                    tipoActuacion = cursor.getString(typeIndex),
                    producto = if (cursor.isNull(productIndex)) null else cursor.getString(productIndex),
                    cantidad = if (cursor.isNull(quantityIndex)) null else cursor.getDouble(quantityIndex),
                    unidad = if (cursor.isNull(unitIndex)) null else cursor.getString(unitIndex),
                    textoOriginal = cursor.getString(originalIndex),
                    estado = cursor.getString(statusIndex),
                    createdAt = cursor.getString(createdIndex)
                )
            }
        }
        return result
    }
}
