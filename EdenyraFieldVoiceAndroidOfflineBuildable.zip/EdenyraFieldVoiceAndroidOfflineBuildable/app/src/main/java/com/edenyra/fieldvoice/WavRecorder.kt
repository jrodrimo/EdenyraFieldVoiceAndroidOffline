package com.edenyra.fieldvoice

import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import java.io.File
import java.io.RandomAccessFile
import java.util.concurrent.atomic.AtomicBoolean

class WavRecorder {

    companion object {
        private const val SAMPLE_RATE = 16000
        private const val CHANNELS = 1
        private const val BITS_PER_SAMPLE = 16
    }

    private var audioRecord: AudioRecord? = null
    private var recordingThread: Thread? = null
    private val recording = AtomicBoolean(false)

    @Suppress("MissingPermission")
    fun start(file: File) {
        if (recording.get()) return

        val minBuffer = AudioRecord.getMinBufferSize(
            SAMPLE_RATE,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        )
        require(minBuffer > 0) { "El dispositivo no admite grabación PCM 16 kHz mono." }

        val recorder = AudioRecord(
            MediaRecorder.AudioSource.VOICE_RECOGNITION,
            SAMPLE_RATE,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT,
            minBuffer * 2
        )

        require(recorder.state == AudioRecord.STATE_INITIALIZED) {
            recorder.release()
            "No se pudo inicializar el micrófono."
        }

        audioRecord = recorder
        recording.set(true)
        recorder.startRecording()

        recordingThread = Thread {
            writeWav(file, recorder, minBuffer * 2)
        }.apply {
            name = "EdenyraWavRecorder"
            start()
        }
    }

    fun stop() {
        if (!recording.getAndSet(false)) return
        try {
            audioRecord?.stop()
        } catch (_: Exception) {
        }
        try {
            recordingThread?.join(3000)
        } catch (_: InterruptedException) {
            Thread.currentThread().interrupt()
        }
        audioRecord?.release()
        audioRecord = null
        recordingThread = null
    }

    fun release() = stop()

    private fun writeWav(file: File, recorder: AudioRecord, bufferSize: Int) {
        file.parentFile?.mkdirs()
        RandomAccessFile(file, "rw").use { out ->
            out.setLength(0)
            writeHeader(out, 0)

            val buffer = ByteArray(bufferSize)
            var dataBytes = 0L

            while (recording.get()) {
                val read = recorder.read(buffer, 0, buffer.size)
                if (read > 0) {
                    out.write(buffer, 0, read)
                    dataBytes += read
                }
            }

            writeHeader(out, dataBytes)
        }
    }

    private fun writeHeader(out: RandomAccessFile, dataSize: Long) {
        val byteRate = SAMPLE_RATE * CHANNELS * BITS_PER_SAMPLE / 8
        val blockAlign = CHANNELS * BITS_PER_SAMPLE / 8
        val riffSize = 36 + dataSize

        out.seek(0)
        out.writeBytes("RIFF")
        writeLittleEndianInt(out, riffSize.toInt())
        out.writeBytes("WAVE")
        out.writeBytes("fmt ")
        writeLittleEndianInt(out, 16)
        writeLittleEndianShort(out, 1)
        writeLittleEndianShort(out, CHANNELS)
        writeLittleEndianInt(out, SAMPLE_RATE)
        writeLittleEndianInt(out, byteRate)
        writeLittleEndianShort(out, blockAlign)
        writeLittleEndianShort(out, BITS_PER_SAMPLE)
        out.writeBytes("data")
        writeLittleEndianInt(out, dataSize.toInt())
    }

    private fun writeLittleEndianInt(out: RandomAccessFile, value: Int) {
        out.write(value and 0xFF)
        out.write((value shr 8) and 0xFF)
        out.write((value shr 16) and 0xFF)
        out.write((value shr 24) and 0xFF)
    }

    private fun writeLittleEndianShort(out: RandomAccessFile, value: Int) {
        out.write(value and 0xFF)
        out.write((value shr 8) and 0xFF)
    }
}
