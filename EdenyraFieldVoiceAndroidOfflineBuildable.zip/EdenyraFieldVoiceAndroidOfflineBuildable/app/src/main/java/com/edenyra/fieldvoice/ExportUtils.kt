package com.edenyra.fieldvoice

import org.json.JSONArray
import org.json.JSONObject

object ExportUtils {

    fun toCsv(actions: List<FieldAction>): String {
        val lines = mutableListOf(
            listOf(
                "id", "fecha", "parcela", "tipo_actuacion", "producto", "cantidad",
                "unidad", "estado", "texto_original", "created_at"
            ).joinToString(",")
        )

        actions.forEach { a ->
            lines += listOf(
                a.id.toString(),
                a.fecha,
                a.parcela,
                a.tipoActuacion,
                a.producto.orEmpty(),
                a.cantidad?.toString().orEmpty(),
                a.unidad.orEmpty(),
                a.estado,
                a.textoOriginal,
                a.createdAt
            ).joinToString(",") { csvEscape(it) }
        }
        return lines.joinToString("\n")
    }

    fun toJson(actions: List<FieldAction>): String {
        val array = JSONArray()
        actions.forEach { a ->
            array.put(JSONObject().apply {
                put("id", a.id)
                put("fecha", a.fecha)
                put("parcela", a.parcela)
                put("tipo_actuacion", a.tipoActuacion)
                put("producto", a.producto ?: JSONObject.NULL)
                put("cantidad", a.cantidad ?: JSONObject.NULL)
                put("unidad", a.unidad ?: JSONObject.NULL)
                put("estado", a.estado)
                put("texto_original", a.textoOriginal)
                put("created_at", a.createdAt)
            })
        }
        return array.toString(2)
    }

    private fun csvEscape(value: String): String {
        val escaped = value.replace("\"", "\"\"")
        return if (value.contains(',') || value.contains('\"') || value.contains('\n')) {
            "\"$escaped\""
        } else {
            escaped
        }
    }
}
